# Foray
Social networking app that empowers people to foray into different hobbies and interests.

How to build:

Simply clone the repository with the Node Package Manager (npm) and expo-cli installed:

```
npm install --global expo-cli
git clone https://github.com/LeftPhalange/Foray.git
```
