export type RootStackParamList = {
  Root: undefined;
  NotFound: undefined;
};

// TODO: add more tabs
export type BottomTabParamList = {
  Feed: undefined;
  Settings: undefined;
};

export type FeedTabParamList = {
  FeedTabScreen: undefined;
};

export type SettingsTabParamList = {
  SettingsTabScreen: undefined;
};
